const { handler } = require('./generatePresignedUrl');

exports.handler = handler; 